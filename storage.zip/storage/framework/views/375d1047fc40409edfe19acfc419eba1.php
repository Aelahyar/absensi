<?php $__env->startSection('content'); ?>
<div class="page-heading">
    <div class="page-title">
        <div class="row">
            <div class="col-12 col-md-6 order-md-2 order-first">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="/dashboardadmin">Dashboard</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Guru</li>
                    </ol>
                </nav>
            </div>
        </div>
    </div>

    <section class="section">
        <div class="col-md-12">
            <div class="card border border-primary border-3 mt-2">
                <div class="card-body">
                    <div class="card">
                        
                        <div class="card-header">
                            <h5 class="card-title">
                                <div class="col-sm-12 d-flex justify-content-between">
                                    Data Guru
                                    <button type="button"
                                        class="btn btn-outline-success rounded-pill"
                                        data-bs-toggle="modal"
                                        data-bs-target="#addGuru">
                                        <strong>Add Data</strong>
                                    </button>
                                </div>
                            </h5>
                        </div>

                        
                        <div class="modal fade text-left modal-borderless" id="addGuru" tabindex="-1" role="dialog"
                            aria-labelledby="modalAddGuru" aria-hidden="true">
                            <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable" role="document">
                                <div class="modal-content">
                                    <form method="POST" action="<?php echo e(route('guru.store')); ?>">
                                        <?php echo csrf_field(); ?>
                                        <div class="modal-header bg-primary">
                                            <h4 class="modal-title text-white">Tambah Guru</h4>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>

                                        <div class="modal-body">
                                            
                                            <label><strong>Nik</strong></label>
                                            <div class="form-group mb-2">
                                                <input name="nik" type="text" class="form-control <?php $__errorArgs = ['nik'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                    placeholder="Nomer Induk Keluarga" value="<?php echo e(old('nik')); ?>" required>
                                                <?php $__errorArgs = ['nik'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>

                                            
                                            <label><strong>Nama Guru</strong></label>
                                            <div class="form-group mb-2">
                                                <input name="nama_guru" type="text" class="form-control <?php $__errorArgs = ['nama_guru'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                    placeholder="Nama Lengkap Guru" value="<?php echo e(old('nama_guru')); ?>" required>
                                                <?php $__errorArgs = ['nama_guru'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>

                                            
                                            <label><strong>Email</strong></label>
                                            <div class="form-group mb-2">
                                                <input name="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                    placeholder="Example@gmail.com" value="<?php echo e(old('email')); ?>" required>
                                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>

                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Batal</button>
                                            <button type="submit" class="btn btn-primary ms-1">Tambah</button>
                                        </div>
                                    </form>

                                </div>
                            </div>
                        </div>

                        
                        <div class="card-body" style="overflow: auto;">
                            <div class="table-responsive">
                                <table id="table1" class="display table-striped" style="width:100%">
                                    <thead>
                                        <tr>
                                            <th class="text-center">No</th>
                                            <th class="text-center">NIK</th>
                                            <th class="text-center">Nama Guru</th>
                                            <th class="text-center">Email</th>
                                            <th class="text-center">Status</th>
                                            <th class="text-center">Aksi</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__empty_1 = true; $__currentLoopData = $guru; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <tr>
                                                <td class="text-center"><?php echo e($i + 1); ?></td>
                                                <td class="text-center"><?php echo e($g->nik); ?></td>
                                                <td class="text-center"><?php echo e($g->nama_guru); ?></td>
                                                <td class="text-center"><?php echo e($g->email); ?></td>
                                                <td class="text-center">
                                                    <?php if($g->status == 'Y'): ?>
                                                        <span class="badge bg-success">Aktif</span>
                                                    <?php else: ?>
                                                        <span class="badge bg-danger">Non-Aktif</span>
                                                    <?php endif; ?>
                                                </td>
                                                <td class="text-center">
                                                    <div class="d-flex justify-content-center gap-1">
                                                        
                                                        <button class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#editGuru<?php echo e($g->id_guru); ?>">
                                                            <i class="bi bi-pencil-square"></i>
                                                        </button>
                                                        
                                                        <form id="deleteForm<?php echo e($g->id_guru); ?>" action="<?php echo e(route('guru.destroy', $g->id_guru)); ?>" method="POST">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('DELETE'); ?>
                                                            <button type="button" class="btn btn-link p-0" onclick="confirmDelete(<?php echo e($g->id_guru); ?>)">
                                                                <i class="bi bi-trash3 text-danger fs-5"></i>
                                                            </button>
                                                        </form>
                                                    </div>
                                                </td>
                                            </tr>
                                        
                                        <div class="modal fade" id="editGuru<?php echo e($g->id_guru); ?>" tabindex="-1" role="dialog">
                                            <div class="modal-dialog modal-dialog-centered" role="document">
                                                <div class="modal-content">
                                                    <form action="<?php echo e(route('guru.update', $g->id_guru)); ?>" method="POST">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('PUT'); ?>
                                                        <div class="modal-header bg-warning">
                                                            <h5 class="modal-title text-white">Edit Data Guru</h5>
                                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                        </div>

                                                        <div class="modal-body">
                                                            <div class="form-group mb-3">
                                                                <label><strong>NIK</strong></label>
                                                                <input type="text" name="nik" class="form-control" value="<?php echo e($g->nik); ?>" required>
                                                            </div>

                                                            <div class="form-group mb-3">
                                                                <label><strong>Nama Guru</strong></label>
                                                                <input type="text" name="nama_guru" class="form-control" value="<?php echo e($g->nama_guru); ?>" required>
                                                            </div>

                                                            <div class="form-group mb-3">
                                                                <label><strong>Email</strong></label>
                                                                <input type="email" name="email" class="form-control" value="<?php echo e($g->email); ?>" required>
                                                            </div>

                                                            <div class="form-group mb-3">
                                                                <!-- Hidden input akan dikirim jika checkbox tidak dicentang -->
                                                                <input type="hidden" name="status" value="N">

                                                                <!-- Checkbox ini akan override jadi 1 jika dicentang -->
                                                                <input class="form-check-input" type="checkbox" name="status" value="Y" id="statusCheck<?php echo e($g->id_guru); ?>" <?php echo e($g->status == "Y" ? 'checked' : ''); ?>>
                                                                <label class="form-check-label" for="statusCheck<?php echo e($g->id_guru); ?>">
                                                                    Aktifkan
                                                                </label>
                                                            </div>

                                                        </div>

                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                                                            <button type="submit" class="btn btn-warning">Simpan</button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            <div class="alert alert-danger">
                                                Data Guru belum Tersedia.
                                            </div>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<?php if($errors->any()): ?>
<script>
    document.addEventListener("DOMContentLoaded", function() {
        var modal = new bootstrap.Modal(document.getElementById('addGuru'));
        modal.show();


        // SweetAlert untuk error validasi
        Swal.fire({
                title: 'Gagal Menyimpan!',
                html: `<?php echo implode('<br>', $errors->all()); ?>`,
                icon: 'error',
                toast: true,
                position: 'top-end',
                showConfirmButton: false,
                timer: 4000
            });
    });
</script>
<?php endif; ?>

<script>
    function confirmDelete(id_guru) {
        Swal.fire({
            title: 'Yakin ingin menghapus?',
            text: "Data yang dihapus tidak bisa dikembalikan!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Ya, hapus!',
            cancelButtonText: 'Batal'
        }).then((result) => {
            if (result.isConfirmed) {
                document.getElementById('deleteForm' + id_guru).submit();
            }
        });
    }
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\request\absensi\resources\views/layout/admin/guru.blade.php ENDPATH**/ ?>