<?php $__env->startSection('content'); ?>

<div class="page-heading">
    <div class="page-title">
        <div class="row">
            <div class="col-12 col-md-6 order-md-2 order-first">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="/dashboardadmin">Dashboard</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Tahun Pelajaran</li>
                    </ol>
                </nav>
            </div>
        </div>
    </div>

    
    <section class="section">
        <div class="col-md-12">
            <div class="card border border-primary border-3 mt-2">
                <div class="card-body">
                    <div class="card">
                        
                        <div class="card-header">
                            <h5 class="card-title">
                                <div class="col-sm-12 d-flex justify-content-between">
                                    Data Tahun Pelajaran
                                    <button type="button" class="btn btn-outline-success rounded-pill" data-bs-toggle="modal" data-bs-target="#addTahunPelajaran">
                                        <strong>Add Data</strong>
                                    </button>
                                </div>
                            </h5>
                        </div>

                        
                        <div class="card-body" style="overflow: auto;">
                            <div class="table-responsive">
                                <table id="table1" class="display" style="width:100%">
                                    <thead>
                                        <tr>
                                            <th class="text-center">No</th>
                                            <th class="text-center">Tahun Pelajaran</th>
                                            <th class="text-center">Status</th>
                                            <th class="text-center">Aksi</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $ta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <tr>
                                                <td class="text-center"><?php echo e($no + 1); ?></td>
                                                <td class="text-center"><strong><?php echo e($ta->tahun_ajaran); ?></strong></td>
                                                <td class="text-center">
                                                    <?php if($ta->status == 1): ?>
                                                        <span class="badge bg-success">Aktif</span>
                                                    <?php else: ?>
                                                        <span class="badge bg-danger">Tidak Aktif</span>
                                                    <?php endif; ?>
                                                </td>
                                                <td class="text-center">
                                                
                                                <?php if($ta->status == 1): ?>
                                                    
                                                    <a href="javascript:void(0);"
                                                        class="btn btn-danger btn-sm"
                                                        onclick="confirmUpdateStatus('<?php echo e(route('tahunajaran.setStatus', ['id_thajaran' => $ta->id_thajaran, 'status' => 0])); ?>', 'nonaktifkan')">
                                                            <i class="fas fa-times-circle"></i> Nonaktifkan
                                                        </a>
                                                <?php else: ?>
                                                    
                                                    <a href="javascript:void(0);"
                                                        class="btn btn-success btn-sm"
                                                        onclick="confirmUpdateStatus('<?php echo e(route('tahunajaran.setStatus', ['id_thajaran' => $ta->id_thajaran, 'status' => 1])); ?>', 'aktifkan')">
                                                            <i class="fas fa-check-circle"></i> Aktifkan
                                                        </a>
                                                <?php endif; ?>

                                                    
                                                    <button class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#editTahunPelajaran<?php echo e($ta->id_thajaran); ?>">
                                                        <i class="bi bi-pencil-square"></i> Edit
                                                    </button>

                                                    
                                                    <form action="<?php echo e(route('tahunajaran.destroy', $ta->id_thajaran)); ?>" method="POST" class="d-inline" id="deleteForm<?php echo e($ta->id_thajaran); ?>">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <button type="button" class="btn btn-danger btn-sm" onclick="confirmDelete(<?php echo e($ta->id_thajaran); ?>)">
                                                            <i class="bi bi-trash3"></i> Hapus
                                                        </button>
                                                    </form>
                                                </td>
                                            </tr>

                                            
                                            <div class="modal fade" id="editTahunPelajaran<?php echo e($ta->id_thajaran); ?>" tabindex="-1" role="dialog">
                                                <div class="modal-dialog modal-dialog-centered" role="document">
                                                    <div class="modal-content">
                                                        <form action="<?php echo e(route('tahunajaran.update', $ta->id_thajaran)); ?>" method="POST">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('PUT'); ?>
                                                            <div class="modal-header bg-warning">
                                                                <h5 class="modal-title text-white">Edit Tahun Pelajaran</h5>
                                                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                            </div>
                                                            <div class="modal-body">
                                                                <div class="form-group mb-3">
                                                                    <label><strong>Tahun Pelajaran</strong></label>
                                                                    <input type="text" name="tahun_ajaran" class="form-control" value="<?php echo e($ta->tahun_ajaran); ?>" required>
                                                                </div>
                                                                <div class="form-check">
                                                                    <!-- Hidden input akan dikirim jika checkbox tidak dicentang -->
                                                                    <input type="hidden" name="status" value="0">

                                                                    <!-- Checkbox ini akan override jadi 1 jika dicentang -->
                                                                    <input class="form-check-input" type="checkbox" name="status" value="1" id="statusCheck<?php echo e($ta->id_thajaran); ?>" <?php echo e($ta->status == 1 ? 'checked' : ''); ?>>
                                                                    <label class="form-check-label" for="statusCheck<?php echo e($ta->id_thajaran); ?>">
                                                                        Aktifkan
                                                                    </label>
                                                                </div>
                                                            </div>
                                                            <div class="modal-footer">
                                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                                                                <button type="submit" class="btn btn-warning">Simpan</button>
                                                            </div>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <div class="alert alert-danger">
                                            Data Tahun Pelajaran belum Tersedia.
                                        </div>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>

                        
                        <div class="modal fade" id="addTahunPelajaran" tabindex="-1" role="dialog">
                            <div class="modal-dialog modal-dialog-centered" role="document">
                                <div class="modal-content">
                                    <form action="<?php echo e(route('tahunajaran.store')); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <div class="modal-header bg-primary">
                                            <h5 class="modal-title text-white">Tambah Tahun Pelajaran</h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body">
                                            <div class="form-group mb-3">
                                                <label><strong>Tahun Pelajaran</strong></label>
                                                <input name="tahun_ajaran" type="text" placeholder="2024/2025" class="form-control" required>
                                            </div>
                                            <div class="form-check">
                                                <input class="form-check-input" type="checkbox" name="status" value="1" id="statusBaru">
                                                <label class="form-check-label" for="statusBaru">
                                                    Aktifkan
                                                </label>
                                            </div>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Batal</button>
                                            <button type="submit" class="btn btn-primary">Tambah</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>

                    </div> <!-- inner card -->
                </div>
            </div>
        </div>
    </section>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    function confirmUpdateStatus(url, action) {
        Swal.fire({
            title: `Yakin ingin ${action} tahun ajaran ini?`,
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Ya, lanjutkan!',
            cancelButtonText: 'Batal'
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = url;
            }
        });
    }
    function confirmDelete(id_thajaran) {
        Swal.fire({
            title: 'Yakin ingin menghapus?',
            text: "Data yang dihapus tidak dapat dikembalikan!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Ya, hapus!',
            cancelButtonText: 'Batal'
        }).then((result) => {
            if (result.isConfirmed) {
                document.getElementById('deleteForm' + id_thajaran).submit();
            }
        });
    }
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\request\absensi\resources\views/layout/admin/tahun.blade.php ENDPATH**/ ?>