<?php $__env->startSection('content'); ?>
    <form method="POST" action="/admin/login" class="login100-form validate-form">
        <?php echo csrf_field(); ?>
        <span class="login100-form-title p-b-30">
            <img src="<?php echo e(asset('assets/img/mts.png')); ?>" width="150">
        </span>
        <span class="login100-form-title p-b-26">
            MTs AL-ANWAR JOMBANG
        </span>

        
        <div class="wrap-input100 validate-input">
            <input class="input100" type="text" name="username" required>
            <span class="focus-input100" data-placeholder="Username"></span>
        </div>

        <div class="wrap-input100 validate-input" data-validate="Password">
            <span class="btn-show-pass">
                <i class="zmdi zmdi-eye"></i>
            </span>
            <input class="input100" type="password" name="password" required>
            <span class="focus-input100" data-placeholder="Password"></span>
        </div>

        <div class="container-login100-form-btn">
            <div class="wrap-login100-form-btn">
                <div class="login100-form-bgbtn"></div>
                <button type="submit" class="login100-form-btn">
                    Login
                </button>
            </div>
        </div>
    </form>

    
    <?php if(session('success')): ?>
    <script>
        Swal.fire({
            title: 'Success!',
            text: '<?php echo e(session('success')); ?>',
            icon: 'success',
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 2000 // Durasi tampilan SweetAlert dalam milidetik
        });
    </script>
    <?php endif; ?>

    <?php if(session('warning')): ?>
    <script>
        setTimeout(() => {
            Swal.fire({
                toast: true,
                position: 'top-end',
                icon: 'warning',
                title: '<?php echo e(session('warning')); ?>',
                showConfirmButton: false,
                timer: 3000,
                timerProgressBar: true,
            });
        }, 100);
    </script>
    <?php endif; ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\request\absensi\resources\views/auth/admin.blade.php ENDPATH**/ ?>