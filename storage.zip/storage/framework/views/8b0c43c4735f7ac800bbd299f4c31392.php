<?php $__env->startSection('content'); ?>
<div class="page-heading">
    <div class="page-title">
        <div class="row">
            <div class="col-12 col-md-6 order-md-2 order-first">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="/dashboardadmin">Dashboard</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Kelas</li>
                    </ol>
                </nav>
            </div>
        </div>
    </div>
    <section class="section">
        <div class="col-md-12">
            <div class="card border border-primary border-3 mt-2">
                <div class="card-body">
                    <div class="card">
                        
                        <div class="card-header">
                            <h5 class="card-title">
                                <div class="col-sm-12 d-flex justify-content-between">
                                    Data Kelas
                                    <button href="<?php echo e(route('kelasadmin.store')); ?>" type="button"
                                        class="btn btn-outline-success rounded-pill" data-bs-toggle="modal"
                                        data-bs-target="#inlineForm">
                                        <strong>Add Data</strong>
                                    </button>
                                </div>
                            </h5>
                        </div>
                        
                        <div class="modal fade text-left modal-borderless" id="inlineForm" tabindex="-1" role="dialog"
                            aria-labelledby="myModalLabel33" aria-hidden="true">
                            <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable" role="document">
                                <div class="modal-content">
                                    <div class="modal-header bg-primary">
                                        <h4 class="modal-title white" id="myModalLabel33">Input Data Kelas</h4>
                                        <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                                            <i data-feather="x"></i>
                                        </button>
                                    </div>
                                    <form action="<?php echo e(route('kelasadmin.store')); ?>" method="POST">
                                        <div class="modal-body">
                                            <?php echo csrf_field(); ?>
                                            <label><strong>Kode Kelas</strong></label>
                                            <div class="form-group">
                                                    <input name="kd_kelas" type="text" value="KL-<?php echo e(time()); ?>" class="form-control" readonly>
                                            </div>
                                            <label><strong>Nama Kelas</strong></label>
                                            <div class="form-group">
                                                <input type="text" name="nama_kelas" placeholder="Masukan Nama Kelas"
                                                    class="form-control <?php $__errorArgs = ['nama_kelas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required
                                                    oninvalid="this.setCustomValidity('Mohon isi Nama Kelas')"
                                                    oninput="this.setCustomValidity('')">
                                            </div>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-danger" data-bs-dismiss="modal">
                                                <i class="bx bx-x d-block d-sm-none"></i>
                                                <span class="d-none d-sm-block">Batal</span>
                                            </button>
                                            <button type="submit" id="toast-success" class="btn btn-primary ms-1">
                                                <span id="toast-success" class="d-none d-sm-block">Tambah</span>
                                            </button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>



                        
                        <div class="card-body" style="overflow: auto;">
                            <div class="table-responsive">
                                <table id="table1" class="display" style="width:100%">
                                    <thead>
                                        <tr>
                                            <th scope="col" class="text-center">No</th>
                                            <th scope="col" class="text-center">Kode Kelas</th>
                                            <th scope="col" class="text-center">Nama Kelas</th>
                                            <th scope="col" class="text-center">AKSI</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__empty_1 = true; $__currentLoopData = $kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $Prsh): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <tr>
                                                <td class="text-center"><?php echo e($no+1); ?></td>
                                                <td class="text-center"><?php echo e($Prsh->kd_kelas); ?></td>
                                                <td class="text-center"><?php echo e($Prsh->nama_kelas); ?></td>
                                                <td class="text-center">
                                                    <div class="d-flex justify-content-center align-items-center gap-1">
                                                        
                                                        <button class="btn btn-link p-0" data-bs-toggle="modal" data-bs-target="#editKelas<?php echo e($Prsh->id_mkelas); ?>">
                                                            <i class="bi bi-pencil-square text-success fs-5"></i>
                                                        </button>

                                                        
                                                        <form id="deleteForm<?php echo e($Prsh->id_mkelas); ?>" action="<?php echo e(route('kelasadmin.destroy', $Prsh->id_mkelas)); ?>" method="POST">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('DELETE'); ?>
                                                            <button type="button" class="btn btn-link p-0" onclick="confirmDelete(<?php echo e($Prsh->id_mkelas); ?>)">
                                                                <i class="bi bi-trash3 text-danger fs-5"></i>
                                                            </button>
                                                        </form>
                                                    </div>
                                                </td>

                                            </tr>

                                            <!-- Modal Edit -->
                                            <div class="modal fade text-left modal-borderless" id="editKelas<?php echo e($Prsh->id_mkelas); ?>" tabindex="-1" role="dialog"
                                                aria-labelledby="editModalLabel<?php echo e($Prsh->id_mkelas); ?>" aria-hidden="true">
                                                <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable" role="document">
                                                    <div class="modal-content">
                                                        <form method="POST" action="<?php echo e(route('kelasadmin.update', $Prsh->id_mkelas)); ?>">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('PUT'); ?>
                                                            <div class="modal-header bg-warning">
                                                                <h4 class="modal-title white" id="editModalLabel<?php echo e($Prsh->id_mkelas); ?>">Edit Kelas</h4>
                                                                <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                                                                    <i data-feather="x"></i>
                                                                </button>
                                                            </div>
                                                            <div class="modal-body">
                                                                <div class="form-group">
                                                                    <label><strong>Nama Kelas</strong></label>
                                                                    <input name="nama_kelas" type="text" value="<?php echo e($Prsh->nama_kelas); ?>"
                                                                        class="form-control <?php $__errorArgs = ['nama_kelas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required
                                                                        oninvalid="this.setCustomValidity('Mohon isi Nama Kelas')"
                                                                        oninput="this.setCustomValidity('')">
                                                                </div>
                                                            </div>
                                                            <div class="modal-footer">
                                                                <button type="button" class="btn btn-danger" data-bs-dismiss="modal">
                                                                    <i class="bx bx-x d-block d-sm-none"></i>
                                                                    <span class="d-none d-sm-block">Batal</span>
                                                                </button>
                                                                <button type="submit" class="btn btn-warning ms-1">
                                                                    <span class="d-none d-sm-block">Simpan</span>
                                                                </button>
                                                            </div>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            <div class="alert alert-danger">
                                                Data Kelas belum Tersedia.
                                            </div>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    function confirmDelete(id_mklas) {
        Swal.fire({
            title: 'Yakin ingin menghapus?',
            text: "Data yang dihapus tidak bisa dikembalikan!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Ya, hapus!',
            cancelButtonText: 'Batal'
        }).then((result) => {
            if (result.isConfirmed) {
                document.getElementById('deleteForm' + id_mklas).submit();
            }
        });
    }
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\request\absensi\resources\views/layout/admin/kelas.blade.php ENDPATH**/ ?>